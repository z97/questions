# About Java

- java for smartphone - mobile app
- internet app
- - pc app which run from browser
- - serverlet Java which run from web-server for delivery web-app
- - applet viewed from browser 

## Frames -> Modules -> Package

## Variables:
- int
- float
- char
- String
- byte
- short
- long
- boolean